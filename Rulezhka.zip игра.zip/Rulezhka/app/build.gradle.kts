plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rulezhka.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rulezhka.game"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Скачиваем three.js внутрь приложения при сборке, чтобы игра работала без интернета.
val fetchThree = tasks.register("fetchThree") {
    val out = file("src/main/assets/three.min.js")
    doLast {
        if (!out.exists() || out.length() < 100_000L) {
            try {
                val bytes = java.net.URL(
                    "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"
                ).readBytes()
                out.parentFile.mkdirs()
                out.writeBytes(bytes)
            } catch (e: Exception) {
                logger.warn("three.js не скачался: игра возьмёт его из интернета при запуске")
            }
        }
    }
}
tasks.configureEach {
    if (name == "preBuild") dependsOn(fetchThree)
}
